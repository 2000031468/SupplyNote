from flask import render_template, url_for, flash, redirect
from app import app, db, login_manager
from app.models import User, ShortLink
from flask_login import login_user, current_user, logout_user, login_required
from flask import request
from datetime import datetime, timedelta

@app.route("/")
@app.route("/home")
def home():
    return render_template('index.html')

@app.route("/login", methods=['GET', 'POST'])
def login():
    # Your login logic here
    return render_template('login.html')

@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for('home'))

@app.route("/dashboard", methods=['GET', 'POST'])
@login_required
def dashboard():
    # Your dashboard logic here
    return render_template('dashboard.html')

@app.route("/analytics/<short_url>")
@login_required
def analytics(short_url):
    # Your analytics logic here
    return render_template('analytics.html')

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))
